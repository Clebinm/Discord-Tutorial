const Discord = require('discord.js')

   module.exports = async (bot, oldMessage, newMessage) => { //cuida do evento de mensagens enviadas em chat
     if(oldMessage.author.bot || newMessage.author.bot)
    return;

 let teste = new Discord.MessageEmbed()
    .setColor("RED")
     .setTitle("Mensagem editada!")
   .setDescription("O usuário <@"+oldMessage.author.id+"> modificou uma mensagem\n Antiga mensagem\n"+oldMessage.content+"\nNova Mensagem\n"+newMessage.content)  
 bot.channels.cache.get("id_do_canal").send(teste)

}
